## Dictionary and Corpus

Dictionary files (usually character level vocabulary) are included here for easier configuration. Corpus contributed by OSS contirbutors are listed here, please respect copyrights when using them at your own risk.

- Burmese corpus:  https://github.com/1chimaruGin/BurmeseCorpus
